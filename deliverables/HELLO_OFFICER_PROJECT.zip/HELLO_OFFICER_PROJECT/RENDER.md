# 편집과 렌더

이 폴더에는 index.html, 캐릭터 PNG 14개, 공원과 소품, 대사 WAV, 로컬 GSAP과 글꼴이 있다.
대사 시점은 js/cues.js에, 카메라와 포즈 컷은 js/scenes.js에 기록했다.
Kokoro를 다시 실행하지 않아도 포함된 WAV로 편집과 렌더를 진행할 수 있다.

## 현재 클라우드에서 재생

이 파일이 있는 프로젝트 폴더에서 실행한다.

python3 -m http.server 8765 --bind 127.0.0.1

Chrome에서 해당 로컬 서버의 index.html을 열고 재생 버튼을 누른다.
Space는 일시정지와 재생, R은 처음부터 재생, 좌우 방향키는 0.5초 구간 이동이다.
이 환경의 Chromium은 file://를 차단하므로 HTTP를 사용한다.

## 최종 MP4

bash render_final.sh

제공된 render.py의 프레임별 렌더를 실행하고, FFmpeg로 audio/narration.wav를 직접 합성한다.
H.264, yuv420p, 1920×1080, 30 fps, 1,200프레임, AAC 48 kHz 스테레오와 faststart를 사용한다.
기존 설치본 ../venv/bin/python의 Playwright와 /usr/bin/chromium, ffmpeg가 필요하다.
다른 위치에서는 MOTION_PYTHON과 MOTION_CHROMIUM으로 설치된 실행 파일을 지정한다.
Python 환경은 playwright 1.65.2로 준비했다.

이 프로젝트의 render.py 사본은 MOTION_RENDER_2D=1에서 CPU 합성 경로로 Chromium을 시작한다.
HTML과 PNG 장면의 렌더 부하를 줄이기 위한 선택이며, 프레임별 시각 설정과 안정 캡처·인코딩 로직은 제공된 렌더러를 사용한다.
전역 설치된 스킬은 수정하지 않았다.

## 7초 구간

원본 영상의 13.3–20.3초가 검수 구간이다.

MOTION_RENDER_2D=1 MOTION_CHROMIUM=/usr/bin/chromium ../venv/bin/python render.py . --no-venv --no-audio --from 13.3 --to 20.3 --res 1080p --fps 30 --jobs 2 --chunk 3.5 --out discovery-picture.mp4

ffmpeg -i discovery-picture.mp4 -ss 13.3 -i audio/narration.wav -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -ar 48000 -ac 2 -t 7 -movflags +faststart discovery.mp4

## 음성 수정

대사가 바뀌는 경우에 tools/build_audio.py를 사용한다.
프로젝트 밖 kokoro-local/venv와 models가 현재 클라우드 환경에 준비되어 있다.
모델을 별도 준비할 때의 출처와 라이선스는 SOURCES_AND_LICENSES.md, 패키지 버전은 requirements-tts.txt에 있다.

../kokoro-local/venv/bin/python tools/build_audio.py ../kokoro-local/models

두 배역의 고정 화자와 실제 WAV 길이로 큐를 다시 기록한다.
모델 오디오 입력이나 청취 기능을 사용하지 않는다.

## 검증

../venv/bin/python tools/verify_preparation.py

../venv/bin/python tools/verify_video.py HELLO_OFFICER_40S.mp4 --report qa/final-video.json

정지 프레임 시트는 render.py --screenshot으로 생성한다.
발음·감정의 청취 평가와 실기 갤럭시 검수의 상태는 QA_REPORT.md에 적었다.
