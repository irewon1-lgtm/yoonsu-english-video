Video.define(async ({ tl, cue, cues, scene, onFrame, data, gsap }) => {
  scene('#park', 0, null);
  const cast = window.PARK_CAST;
  const registration = window.CAST_REGISTRATION;
  const actorImages = Object.fromEntries(await Promise.all(Object.entries(cast).map(async ([actor, poses]) => {
    const parent = document.getElementById(actor);
    const items = await Promise.all(Object.entries(poses).map(async ([id, file]) => {
      const image = new Image();
      const fit = registration[file];
      image.alt = '';
      image.src = file;
      image.dataset.pose = id;
      image.style.height = fit.height + 'px';
      image.style.width = fit.width + 'px';
      image.style.bottom = fit.bottom + 'px';
      image.style.left = 'calc(50% + ' + fit.offset + 'px)';
      await image.decode();
      parent.append(image);
      return [id, image];
    }));
    return [actor, Object.fromEntries(items)];
  })));
  await Promise.all([...document.querySelectorAll('#world > img')].map(image => image.decode()));
  await document.fonts.load('780 67px Pretendard', data.cues.map(c => c.text).join(' '));
  await document.fonts.load('580 35px Pretendard', data.cues.map(c => c.ko).join(' ') + '함께 말해요');

  tl.fromTo('#opening', { autoAlpha: 1 }, { autoAlpha: 0, duration: 0.52, ease: 'power1.inOut' }, 3.6);
  tl.fromTo('#discovery', { opacity: 0 }, { opacity: 0.76, duration: 0.25, ease: 'sine.in' }, 16.85);
  tl.to('#discovery', { opacity: 0, duration: 0.65, ease: 'sine.out' }, 17.1);

  // Every PNG stays at its registered world foot point. Shot changes are cuts.
  // The bench and ball retain their original world point in all compositions.
  const framing = {
    wide: { x: 0, y: 0, scale: 1, anchorX: 960, anchorY: 540 },
    y: { x: -288, y: -300, scale: 2.40, anchorX: 520, anchorY: 390 },
    o: { x: -959, y: -300, scale: 1.90, anchorX: 1010, anchorY: 420 },
    point: { x: -605.5, y: -165, scale: 1.55, anchorX: 1010, anchorY: 420 },
    joy: { x: -496, y: -400, scale: 2.80, anchorX: 520, anchorY: 390 },
    ball: { x: -2448, y: -1010, scale: 2.30, anchorX: 1589, anchorY: 654 },
  };
  const shots = [
    { at: 0, frame: 'wide', y: 'wave', o: 'neutral', push: 0 },
    { at: 2.76, frame: 'o', y: 'profile', o: 'wave', push: 0.025 },
    { at: 4.30, frame: 'y', y: 'profile', o: 'neutral', push: 0 },
    { at: 5.00, frame: 'o', y: 'neutral', o: 'listen', push: 0 },
    { at: 5.43, frame: 'y', y: 'neutral', o: 'listen', push: 0.025 },
    { at: 7.65, frame: 'o', y: 'profileAlt', o: 'neutral', push: 0.025 },
    { at: 9.42, frame: 'wide', y: 'profileAlt', o: 'neutral', push: 0 },
    { at: 10.35, frame: 'y', y: 'neutralAlt', o: 'listen', push: 0.025 },
    { at: cue('c05').end + 0.12, frame: 'o', y: 'profileLeft', o: 'listen', push: 0 },
    { at: 13.00, frame: 'y', y: 'profileLeft', o: 'listen', push: 0 },
    { at: 13.65, frame: 'o', y: 'profileLeftAlt', o: 'listen', push: 0 },
    { at: 14.08, frame: 'y', y: 'profileLeftAlt', o: 'listen', push: 0 },
    { at: 14.70, frame: 'wide', y: 'back', o: 'listen', push: 0 },
    { at: 15.14, frame: 'point', y: 'joy', o: 'point', push: 0.025 },
    { at: 16.50, frame: 'ball', y: 'joy', o: 'point', push: 0.035 },
    // The static step pose is shown as a face-and-torso reaction, with feet outside the frame.
    { at: 18.65, frame: 'joy', y: 'joy', o: 'point', push: 0.025 },
    { at: 20.30, frame: 'o', y: 'smile', o: 'listen', push: 0 },
    { at: 21.10, frame: 'y', y: 'smile', o: 'neutral', push: 0.025 },
    { at: 23.18, frame: 'o', y: 'profileAlt', o: 'neutral', push: 0.025 },
    { at: 24.95, frame: 'wide', y: 'profileAlt', o: 'neutral', push: 0 },
    { at: 27, frame: 'wide', y: 'neutral', o: 'neutral', push: 0 },
    { at: 33, frame: 'wide', y: 'smile', o: 'neutral', push: 0 },
    { at: 37, frame: 'o', y: 'wave', o: 'wave', push: 0 },
    { at: 37.18, frame: 'wide', y: 'wave', o: 'wave', push: 0 },
  ];
  window.PARK_SHOTS = shots;
  const ease = gsap.parseEase('sine.inOut');
  const world = document.getElementById('world');
  const park = document.getElementById('park');
  const dialogue = document.getElementById('dialogue');
  const english = document.getElementById('english');
  const korean = document.getElementById('korean');
  let previousShot;
  let previousCue;

  onFrame(t => {
    const index = shots.findLastIndex(shot => shot.at <= t);
    const shot = shots[Math.max(0, index)];
    const nextTime = shots[index + 1]?.at ?? data.duration;
    const base = framing[shot.frame];
    const fraction = Math.max(0, Math.min(1, (t - shot.at) / (nextTime - shot.at)));
    const push = ease(fraction) * shot.push;
    const scale = base.scale * (1 + push);
    const x = base.x - base.anchorX * base.scale * push;
    const y = base.y - base.anchorY * base.scale * push;
    world.style.transform = 'translate(' + x + 'px,' + y + 'px) scale(' + scale + ')';

    if (shot !== previousShot) {
      previousShot = shot;
      park.className = 'scene focus-' + shot.frame;
      for (const role of ['y', 'o']) {
        const wanted = actorImages[role][shot[role]];
        for (const image of Object.values(actorImages[role])) {
          image.classList.toggle('is-active', image === wanted);
        }
      }
    }

    const line = cues.find(c => c.start <= t && t < (c.holdUntil ?? c.end));
    if (line?.id === previousCue) return;
    previousCue = line?.id;
    dialogue.style.visibility = line ? 'visible' : 'hidden';
    dialogue.classList.toggle('review', Boolean(line?.reuse));
    if (!line) return;
    english.replaceChildren();
    if (line.focus) {
      const at = line.text.indexOf(line.focus);
      const focus = document.createElement('strong');
      focus.textContent = line.focus;
      english.append(line.text.slice(0, at), focus, line.text.slice(at + line.focus.length));
    } else {
      english.textContent = line.text;
    }
    korean.textContent = line.ko;
  });
});
