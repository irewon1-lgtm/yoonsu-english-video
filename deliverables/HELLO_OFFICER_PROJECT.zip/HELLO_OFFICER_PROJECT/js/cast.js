// READY PNG files from the supplied asset ZIP. Original pixels are preserved.
window.PARK_CAST = {
  "y": {
    "neutral": "assets/characters/YOONSU/Y01_neutral_front.png",
    "profileLeft": "assets/characters/YOONSU/Y02_profile_left.png",
    "back": "assets/characters/YOONSU/Y03_back.png",
    "profileLeftAlt": "assets/characters/YOONSU/Y04_profile_left_alt.png",
    "smile": "assets/characters/YOONSU/Y05_soft_smile_front.png",
    "profile": "assets/characters/YOONSU/Y06_profile_right.png",
    "profileAlt": "assets/characters/YOONSU/Y07_profile_right_alt.png",
    "neutralAlt": "assets/characters/YOONSU/Y08_neutral_front_alt.png",
    "wave": "assets/characters/YOONSU/Y09_wave.png",
    "joy": "assets/characters/YOONSU/Y10_walk_pose.png"
  },
  "o": {
    "neutral": "assets/characters/LABRADOR/L01_neutral.png",
    "wave": "assets/characters/LABRADOR/L02_wave.png",
    "point": "assets/characters/LABRADOR/L03_present.png",
    "listen": "assets/characters/LABRADOR/L04_listen.png"
  }
};
window.CAST_REGISTRATION = {
  "assets/characters/YOONSU/Y01_neutral_front.png": {
    "height": 648.9854,
    "width": 432.657,
    "bottom": -5.4927,
    "offset": 1.2675,
    "alpha_bbox": [
      215,
      13,
      807,
      1523
    ],
    "sha256": "0758a4d3667c4cf7c5ab3f241beea9b958147db4b3e0babf179517972ff2d34a"
  },
  "assets/characters/YOONSU/Y02_profile_left.png": {
    "height": 655.497,
    "width": 436.998,
    "bottom": -11.5224,
    "offset": 17.497,
    "alpha_bbox": [
      317,
      14,
      731,
      1509
    ],
    "sha256": "8d71673e7267afcb174bab60cbf4215552f4a9d327e1e9e104321b880eeefd36"
  },
  "assets/characters/YOONSU/Y03_back.png": {
    "height": 651.5745,
    "width": 434.383,
    "bottom": -7.2114,
    "offset": 3.1815,
    "alpha_bbox": [
      219,
      15,
      797,
      1519
    ],
    "sha256": "7ec7b13149e6bd940460bd7352f7108f6241e5e1c623d40b0bc5ac9b002a78e9"
  },
  "assets/characters/YOONSU/Y04_profile_left_alt.png": {
    "height": 659.0235,
    "width": 439.349,
    "bottom": -12.8716,
    "offset": 19.7364,
    "alpha_bbox": [
      330,
      19,
      734,
      1506
    ],
    "sha256": "f75aff643e2d1e2effa3e502a396ca2849f4ab444e3f54dada3037efe29c0d0b"
  },
  "assets/characters/YOONSU/Y05_soft_smile_front.png": {
    "height": 650.2774,
    "width": 433.5182,
    "bottom": -1.2701,
    "offset": 3.3869,
    "alpha_bbox": [
      221,
      26,
      799,
      1533
    ],
    "sha256": "944efc79010baf9888a89e5e7ec741d449991d7e0c8896d48b2e51a5643dd925"
  },
  "assets/characters/YOONSU/Y06_profile_right.png": {
    "height": 657.2555,
    "width": 438.1704,
    "bottom": -11.5533,
    "offset": -4.0651,
    "alpha_bbox": [
      268,
      18,
      664,
      1509
    ],
    "sha256": "13efea39b5f73e3db339ec6bbbe988915c6d12d88b8a0777db271686d1d5905f"
  },
  "assets/characters/YOONSU/Y07_profile_right_alt.png": {
    "height": 652.008,
    "width": 434.672,
    "bottom": -4.6693,
    "offset": 3.1836,
    "alpha_bbox": [
      261,
      22,
      661,
      1525
    ],
    "sha256": "e2f4396134b30bb74f16020d0a955536b36fda7ed19b01a7092951e7703e6d65"
  },
  "assets/characters/YOONSU/Y08_neutral_front_alt.png": {
    "height": 649.4155,
    "width": 432.9437,
    "bottom": -5.9192,
    "offset": -2.5368,
    "alpha_bbox": [
      222,
      13,
      803,
      1522
    ],
    "sha256": "feaf0f6f1651e5463174b1699855740869dd7ca0c96b6d16291d36092a6b9ae2"
  },
  "assets/characters/YOONSU/Y09_wave.png": {
    "height": 645.9908,
    "width": 430.6605,
    "bottom": 0.0,
    "offset": 53.8326,
    "alpha_bbox": [
      255,
      19,
      820,
      1536
    ],
    "sha256": "0d8ef92794f4a7c8f54d1205399da321451800417882465e5536421212dc114a"
  },
  "assets/characters/YOONSU/Y10_walk_pose.png": {
    "height": 649.8462,
    "width": 433.2308,
    "bottom": -5.0769,
    "offset": -27.2885,
    "alpha_bbox": [
      234,
      16,
      851,
      1524
    ],
    "sha256": "7ab081360c4930a2d7c3fad906205e4d104bbdf232768915e36e0edce2e5e28d"
  },
  "assets/characters/LABRADOR/L01_neutral.png": {
    "height": 754.2857,
    "width": 565.7143,
    "bottom": -29.4643,
    "offset": 11.7857,
    "alpha_bbox": [
      133,
      88,
      636,
      984
    ],
    "sha256": "94b79cab5724aa431fb42bee65773753def170f60f099420e0728dadc89b23f1"
  },
  "assets/characters/LABRADOR/L02_wave.png": {
    "height": 755.1285,
    "width": 566.3464,
    "bottom": -29.4972,
    "offset": 12.5363,
    "alpha_bbox": [
      108,
      89,
      662,
      984
    ],
    "sha256": "a981e16c09bf32fe1f4519f81b5dd7110e1df5b2285fd768c7a58c3a45b9ace9"
  },
  "assets/characters/LABRADOR/L03_present.png": {
    "height": 755.9732,
    "width": 566.9799,
    "bottom": -30.2685,
    "offset": 14.396,
    "alpha_bbox": [
      85,
      89,
      681,
      983
    ],
    "sha256": "534ffa7323a7706ac88381cea6a32786a1d5119fd233f6b50f41df791fbc683f"
  },
  "assets/characters/LABRADOR/L04_listen.png": {
    "height": 755.1285,
    "width": 566.3464,
    "bottom": -30.2346,
    "offset": -36.8715,
    "alpha_bbox": [
      127,
      88,
      639,
      983
    ],
    "sha256": "79ddd6a8846699959852fe74c5e2aa3cfa93afc0c673353f928fd0efc9de3620"
  }
};
