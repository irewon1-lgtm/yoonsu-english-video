#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
node tools/check_assets.mjs
task_python="${MOTION_PYTHON:-../venv/bin/python}"
export MOTION_RENDER_2D=1
export MOTION_CHROMIUM="${MOTION_CHROMIUM:-$(command -v chromium)}"
"$task_python" render.py . --no-venv --no-audio --fps 30 --res 1080p --codec h264 --jobs 2 --chunk 10 --out .picture-40s.mp4
ffmpeg -nostdin -hide_banner -loglevel error -y -i .picture-40s.mp4 -i audio/narration.wav -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -ar 48000 -ac 2 -t 40 -movflags +faststart HELLO_OFFICER_40S.mp4
ffprobe -v error -count_frames -show_entries stream=codec_name,width,height,pix_fmt,r_frame_rate,nb_read_frames,duration:format=duration -of json HELLO_OFFICER_40S.mp4
