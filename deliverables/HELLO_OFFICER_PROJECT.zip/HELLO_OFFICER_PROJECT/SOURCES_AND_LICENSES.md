# Sources and licenses

The installed script-to-motion source is pinned at commit 8fc16eabd9bbe692722b9df8a10aab4988268585.
Its MIT license is included in licenses/script-to-motion-MIT.txt.
The current installation includes the onboarding changes that remove Claude-only frontmatter hooks and permit selecting the existing Chromium executable through MOTION_CHROMIUM.
Source https://github.com/kstost/script-to-motion

GSAP 3.15.0 and its plugins use the GSAP Standard no-charge license. Their minified files retain the original notices.
This license is distinct from the script-to-motion repository MIT license.
License https://gsap.com/standard-license
Package provenance is preserved in vendor-source-catalog.json, including download hashes.

Pretendard, D2Coding and Noto Sans KR use SIL OFL 1.1. Their original files and license notices remain in fonts/.

Kokoro-82M v1.0 weights use Apache 2.0. kokoro-onnx 0.6.1 uses MIT.
The corresponding license texts are in licenses/.
The official model description states that the weights are Apache-licensed.
Sources https://github.com/hexgrad/kokoro and https://github.com/thewh1teagle/kokoro-onnx
Model downloads https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.0

The local speech build uses two existing synthetic voices, af_nova for Yoonsu and am_michael for Officer Labrador.
Both keep their original pitch. Speed is 0.94 and 0.93 respectively.
These are synthetic acting choices for this project. Their child/adult suitability, emotional expression and Yoonsu pronunciation remain unverified by listening.
Spoken Yoonsu is spelled Yoon-soo for local synthesis while the displayed script keeps Yoonsu.
Existing same-cue WAV takes are reused for the practice sections.

No external speech API was called. tools/build_audio.py is the project's integration with local Kokoro, and writes measured cue data and narration.wav for the installed player.
The Kokoro model files and the Python virtual environments remain in the cloud environment. They are not included in this editing archive.
The project contains the produced WAV files and can render them without the Kokoro model.

The park and bench illustrations were authored for this project.
The 14 character PNG files come from the user-supplied YOONSU_LABRADOR_40S_ASSETS.zip READY folders.
The original PNG bytes, colors and orientation are preserved in the editing source.
The original ZIP, SOURCES and OPTIONAL files remain outside the project in the cloud workspace.
All 10 Yoonsu poses and all four Labrador poses appear in the film. The step pose is framed as a static upper-body reaction.
The supplied asset manifest and per-image hashes are included.

The project copy of render.py adds MOTION_RENDER_2D=1 to launch system Chromium with its CPU compositor for HTML/PNG scenes.
The original frame seeking, stable double-capture, frame counting and encoding paths are retained.
The installed skill package is preserved. The project's render_final.sh enables this local mode.


The project copy of player.js uses visualViewport for mobile scaling and starts playback with an explicit tap. Repeatable seeking was checked after removing the world-layer will-change hint.
