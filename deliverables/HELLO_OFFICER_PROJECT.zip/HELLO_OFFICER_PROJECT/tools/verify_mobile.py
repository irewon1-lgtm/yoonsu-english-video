"""Exercise the HTML play icon with Android-sized touch input without speech input or listening."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import threading

from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent.parent
with ThreadingHTTPServer(('127.0.0.1', 0), partial(SimpleHTTPRequestHandler, directory=root)) as server:
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=shutil.which('chromium'))
            context = browser.new_context(viewport={'width': 412, 'height': 915}, is_mobile=True,
                has_touch=True, device_scale_factor=2,
                user_agent='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36')
            page = context.new_page()
            page.add_init_script('window.Audio = class extends window.Audio { constructor(...args) { super(...args); window.__audioElement = this; } };')
            page.goto(f'http://127.0.0.1:{server.server_port}/index.html')
            page.wait_for_function('window.Video?.renderReady')
            assert page.evaluate('__audioElement.paused && Video.time === 0')
            rect = page.locator('.vp-go').bounding_box()
            page.touchscreen.tap(rect['x'] + rect['width'] / 2, rect['y'] + rect['height'] / 2)
            page.wait_for_function('Video.time > 1.5', timeout=8000)
            sample = page.evaluate('''() => ({
                videoTime: Video.time, audioTime: __audioElement.currentTime,
                paused: __audioElement.paused, audioError: __audioElement.error,
                width: document.querySelector('#stage').getBoundingClientRect().width,
                innerWidth: innerWidth, viewportWidth: visualViewport.width,
                stageTransform: getComputedStyle(document.querySelector('#stage')).transform
            })''')
            print(json.dumps(sample), flush=True)
            assert not sample['paused'] and sample['audioTime'] > 1.4
            assert abs(sample['audioTime'] - sample['videoTime']) < 0.2
            assert sample['width'] <= 412.1
            browser.close()
    finally:
        server.shutdown()
report = {'android_emulation_tap_starts_clock_and_audio': 'PASS', 'observation': sample,
          'physical_galaxy': 'NOT_RUN', 'speech_listening': 'NOT_RUN'}
(root / 'qa/mobile-emulation.json').write_text(json.dumps(report, indent=2) + '\n')
