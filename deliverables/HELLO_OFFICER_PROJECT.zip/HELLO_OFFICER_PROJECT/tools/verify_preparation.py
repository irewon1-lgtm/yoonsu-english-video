"""Check prepared files and timeline without speech input or listening."""
from contextlib import contextmanager
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import threading
import wave

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT.parent / 'ball-qa'
src = (ROOT / 'js/cues.js').read_text()
data = json.loads(src[src.index('{'):src.rindex('}') + 1])
expected = [
    'Hello, Officer!', 'Hello, Yoonsu!', 'Can you help me?', 'Of course!',
    'Where is my ball?', 'Look! There it is!', 'My ball!', 'Thank you!',
    'You’re welcome!', 'Can you help me?', 'Thank you!', 'Goodbye!', 'Bye!',
]
assert [c['text'] for c in data['cues']] == expected
assert data['duration'] == 40
report = {'scope': 'HTML timeline, source audio metadata and PNG loading', 'checks': {}, 'repeat_gaps_seconds': {}}
with wave.open(str(ROOT / 'audio/narration.wav')) as wav:
    assert wav.getnframes() == 960000
    assert wav.getframerate() == 24000 and wav.getsampwidth() == 2
    report['checks']['mix_duration_40_seconds'] = 'PASS'
end = 0
for cue in data['cues']:
    with wave.open(str(ROOT / cue['file'])) as wav:
        duration = wav.getnframes() / wav.getframerate()
    assert duration == cue['duration']
    assert cue['start'] >= end
    assert abs(cue['end'] - cue['start'] - duration) < 1e-8
    end = cue['end']
    if cue.get('reuse'):
        original = next(c for c in data['cues'] if c['id'] == cue['reuse'])
        assert cue['file'] == original['file']
        gap = cue['holdUntil'] - cue['end']
        assert gap >= 2
        report['repeat_gaps_seconds'][cue['id']] = gap
assert 40 - end > 0.6
report['checks']['cue_files_durations_nonoverlap_reuse_and_tail'] = 'PASS'


@contextmanager
def serve():
    handler = partial(SimpleHTTPRequestHandler, directory=str(ROOT))
    with ThreadingHTTPServer(('127.0.0.1', 0), handler) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield f'http://127.0.0.1:{server.server_port}'
        finally:
            server.shutdown()


with serve() as origin, sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=shutil.which('chromium'))
    page = browser.new_page(viewport={'width': 1920, 'height': 1080})
    errors, failed, external = [], [], []
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.on('response', lambda res: failed.append(res.url) if res.status >= 400 else None)
    page.on('request', lambda req: external.append(req.url) if not req.url.startswith(origin + '/') else None)
    page.goto(origin + '/index.html?render')
    page.wait_for_function('window.Video?.renderReady')
    assert page.evaluate('Video.duration') == 40
    assert page.locator('#stage').get_attribute('data-width') == '1920'
    times = [0.9, 6, 12, 15.6, 17.3, 19.4, 22, 28, 34, 39.9]
    state = """() => ({
        camera: getComputedStyle(document.querySelector('#world')).transform,
        dialogue: getComputedStyle(document.querySelector('#dialogue')).visibility,
        english: document.querySelector('#english').textContent,
        korean: document.querySelector('#korean').textContent,
        ball: [getComputedStyle(document.querySelector('.bench')).left,
               getComputedStyle(document.querySelector('.bench')).top],
        practice: getComputedStyle(document.querySelector('#practice')).display
    })"""
    states = {}
    for moment in times:
        page.evaluate('(t) => Video.seek(t)', moment)
        states[moment] = page.evaluate(state)
    for moment in reversed(times):
        page.evaluate('(t) => Video.seek(t)', moment)
        # Text in the hidden subtitle container can retain the previous line, while its visible state stays hidden.
        current = page.evaluate(state)
        expected_state = states[moment].copy()
        if current['dialogue'] == 'hidden':
            for field in ['english', 'korean']:
                current.pop(field)
                expected_state.pop(field)
        assert current == expected_state, (moment, current, expected_state)
    for cue in data['cues']:
        page.evaluate('(t) => Video.seek(t)', cue['start'] + 0.05)
        assert page.locator('#english').inner_text() == cue['text']
        assert page.locator('#korean').inner_text() == cue['ko']
    report['checks']['visible_dom_reverse_seek_and_bilingual_cue_matching'] = 'PASS'
    report['checks']['fixed_bench_position_across_all_seeks'] = 'PASS'
    pose_count = page.locator('.actor img').count()
    assert pose_count == 14
    visible_poses = {'y': set(), 'o': set()}
    shots = page.evaluate('window.PARK_SHOTS')
    for index, shot in enumerate(shots):
        next_time = shots[index + 1]['at'] if index + 1 < len(shots) else 40
        moment = (shot['at'] + next_time) / 2
        page.evaluate('(t) => Video.seek(t)', moment)
        shown = page.evaluate('''() => Object.fromEntries(['y', 'o'].map(role => [
            role, [...document.querySelectorAll('#' + role + ' img')].filter(im => im.checkVisibility({visibilityProperty: true, opacityProperty: true})).map(im => im.dataset.pose)
        ]))''')
        for role, poses in shown.items():
            assert len(poses) <= 1, (moment, role, poses)
            visible_poses[role].update(poses)
        if shot['frame'] == 'wide':
            assert all(len(shown[role]) == 1 for role in ['y', 'o'])
    assert len(visible_poses['y']) == 10 and len(visible_poses['o']) == 4, visible_poses
    report['checks']['character_files_loaded_and_all_14_shown_without_pose_overlap'] = 'PASS'
    report['visible_poses'] = {role: sorted(poses) for role, poses in visible_poses.items()}
    report['loaded_character_images'] = pose_count
    page.goto(origin + '/index.html')
    page.wait_for_function('window.Video?.renderReady')
    page.locator('.vp-go').click()
    page.wait_for_function('Video.time >= 39.99', timeout=48000)
    report['checks']['prepared_html_40_seconds_normal_speed_clock_playback'] = 'PASS'
    assert not (errors or failed or external), (errors, failed, external)
    report['checks']['prepared_html_assets_js_errors_external_requests'] = 'PASS'
    browser.close()

report['checks']['human_speech_listening_pronunciation_emotion'] = 'NOT_RUN'
report['checks']['physical_galaxy'] = 'NOT_RUN'
(RESULTS / 'preparation-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
