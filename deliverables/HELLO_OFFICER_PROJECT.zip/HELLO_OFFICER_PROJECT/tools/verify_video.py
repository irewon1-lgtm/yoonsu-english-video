"""Verify encoded video metadata, full decoding, faststart and normal-speed muted browser playback."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import struct
import subprocess
import threading

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('movie', type=Path)
parser.add_argument('--seconds', type=int, default=40)
parser.add_argument('--report', type=Path, required=True)
args = parser.parse_args()
movie = args.movie.resolve()
probe = json.loads(subprocess.check_output([
    'ffprobe', '-v', 'error', '-count_frames', '-show_streams', '-show_format', '-of', 'json', str(movie)
]))
video = next(s for s in probe['streams'] if s['codec_type'] == 'video')
sound = next(s for s in probe['streams'] if s['codec_type'] == 'audio')
assert (video['codec_name'], video['pix_fmt'], video['width'], video['height']) == ('h264', 'yuv420p', 1920, 1080)
assert video['r_frame_rate'] == '30/1' and int(video['nb_read_frames']) == args.seconds * 30
assert float(video['duration']) == args.seconds
assert sound['codec_name'] == 'aac' and sound['sample_rate'] == '48000' and sound['channels'] == 2
assert abs(float(probe['format']['duration']) - args.seconds) < 0.05
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-i', str(movie), '-f', 'null', '-'], check=True)
atoms = {}
with movie.open('rb') as stream:
    while header := stream.read(8):
        size, kind = struct.unpack('>I4s', header)
        assert size >= 8
        atoms[kind.decode('ascii')] = stream.tell() - 8
        stream.seek(size - 8, 1)
assert atoms['moov'] < atoms['mdat']

with ThreadingHTTPServer(('127.0.0.1', 0), partial(SimpleHTTPRequestHandler, directory=movie.parent)) as server:
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(executable_path=shutil.which('chromium'))
            page = browser.new_page(viewport={'width': 1920, 'height': 1080})
            page.set_content('<video controls muted></video>')
            page.on('pageerror', lambda error: (_ for _ in ()).throw(RuntimeError(str(error))))
            page.evaluate("""async url => {
                const video = document.querySelector('video');
                video.src = url;
                await video.play();
            }""", f'http://127.0.0.1:{server.server_port}/{movie.name}')
            page.wait_for_function('document.querySelector("video").ended', timeout=(args.seconds + 12) * 1000)
            observation = page.locator('video').evaluate("""v => ({
                duration: v.duration, width: v.videoWidth, height: v.videoHeight, error: v.error,
                played: Array.from({length:v.played.length}, (_, i) => [v.played.start(i), v.played.end(i)])
            })""")
            assert observation['error'] is None
            assert observation['width'] == 1920 and observation['height'] == 1080
            assert observation['duration'] == args.seconds
            assert observation['played'][-1][1] >= args.seconds - 0.05
            browser.close()
    finally:
        server.shutdown()
report = {
    'movie': movie.name, 'seconds': args.seconds, 'video_frames': int(video['nb_read_frames']),
    'video_stream_duration': video['duration'], 'audio_stream_duration': sound['duration'],
    'container_duration': probe['format']['duration'], 'encoding_and_frames': 'PASS',
    'full_av_decoding': 'PASS', 'faststart': 'PASS', 'normal_speed_browser_playback_muted': 'PASS',
    'speech_listening': 'NOT_RUN', 'physical_galaxy': 'NOT_RUN', 'browser_observation': observation
}
args.report.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
