import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const context = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, 'js/cast.js'), 'utf8'), context);
const cast = context.window.PARK_CAST;
const required = { y: ['neutral', 'wave', 'smile', 'profile'], o: ['neutral', 'wave', 'point', 'listen'] };
const missing = [];
for (const [role, poses] of Object.entries(required)) {
  for (const pose of poses) {
    const asset = cast?.[role]?.[pose];
    if (!asset || !fs.existsSync(path.join(root, asset))) missing.push(role + '.' + pose);
  }
}
if (missing.length) {
  console.error('BLOCKED — Original character PNG files must be imported and visually checked before final rendering.');
  console.error('Missing cast slots — ' + missing.join(', '));
  process.exitCode = 1;
} else {
  console.log('PASS — All planned character image files exist. Alpha, appearance, scale and eye-line review still apply.');
}
