# 캐릭터 자산과 보존

사용자 파일 YOONSU_LABRADOR_40S_ASSETS.zip의 READY/YOONSU PNG 10개와 READY/LABRADOR PNG 4개를 사용했다.
ZIP SHA256은 87037ac5be381147bc999d38e2cccab417384aa1c411cd63b9dba31ab79e3d09다.

원본 ZIP과 전체 압축 해제 결과는 프로젝트 밖 assets-originals/YOONSU_LABRADOR_40S_ASSETS에 보존했다.
프로젝트의 assets/characters/YOONSU와 LABRADOR 파일은 READY 파일과 바이트가 일치한다.
PNG를 다시 그리거나 좌우로 반전하지 않았다. OPTIONAL 폴더의 캐릭터는 본편에 포함하지 않았다.

| 항목 | 확인 결과 |
|---|---|
| 실제 RGBA | 14개 모두 확인 |
| 실제 투명 영역 | 모든 이미지에서 알파 0인 픽셀 확인 |
| 몸 크기와 발 | 알파 64 초과 영역과 신발 기준으로 CSS 배치 |
| 경장 스타일 | 동일한 READY 4개 PNG |
| 사용한 윤수 포즈 | 10개 모두 실제 화면에 등장 |
| 사용한 경장 포즈 | 중립, 인사, 소개, 듣기 4개 |
| 포즈 중첩 | 컷마다 한 배역의 보이는 PNG 최대 1개 |
| 정적 걸음 포즈 | Y10은 기쁨의 얼굴·상체 컷으로 사용 |
| 원본 해시 | assets/characters/manifest.csv와 qa/asset-registration.json |

발의 기준점은 두 배역 모두 공통 세계 좌표 y=858이다.
윤수는 화면 왼쪽, 경장은 오른쪽이다.
전신 컷에서 발과 접지 그림자를 맞추고, 단독 클로즈업은 컷으로 연결한다.
표정·포즈는 제공된 정적 PNG를 사용하며, 눈과 입을 별도로 움직이는 리깅은 포함하지 않는다.
